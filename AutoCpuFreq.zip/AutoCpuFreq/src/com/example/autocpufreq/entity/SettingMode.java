package com.example.autocpufreq.entity;

public class SettingMode {
     String name;
     String cup_freq_max;
     String cup_freq_min;
     String battery_tmp;
     public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCup_freq_max() {
		return cup_freq_max;
	}
	public void setCup_freq_max(String cup_freq_max) {
		this.cup_freq_max = cup_freq_max;
	}
	public String getCup_freq_min() {
		return cup_freq_min;
	}
	public void setCup_freq_min(String cup_freq_min) {
		this.cup_freq_min = cup_freq_min;
	}
	public String getBattery_tmp() {
		return battery_tmp;
	}
	public void setBattery_tmp(String battery_tmp) {
		this.battery_tmp = battery_tmp;
	}
	
	
}
