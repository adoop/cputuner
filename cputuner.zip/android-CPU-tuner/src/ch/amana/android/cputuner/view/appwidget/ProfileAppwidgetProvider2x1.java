package ch.amana.android.cputuner.view.appwidget;

public class ProfileAppwidgetProvider2x1 extends ProfileAppwidgetProvider {

}
