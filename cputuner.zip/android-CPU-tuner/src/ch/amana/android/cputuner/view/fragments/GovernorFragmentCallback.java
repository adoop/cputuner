package ch.amana.android.cputuner.view.fragments;

public interface GovernorFragmentCallback {

	void updateModel();

	void updateView();

}
